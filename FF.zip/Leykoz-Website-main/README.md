# Leykemiyalı uşaqlar xeyriyyə cəmiyyətinin rəsmi internet portalı.
Leykemiyalı uşaqlar cəmiyyəti üçün hazırlanmışdır. 
leykoz.az & https://leykoz.az/
